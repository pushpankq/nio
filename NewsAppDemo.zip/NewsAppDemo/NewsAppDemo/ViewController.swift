//
//  ViewController.swift
//  NewsAppDemo
//
//  Created by Mayank Singh on 29/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class NewsFeedsVC: UITableViewController {
    
    static let cellIdentifier = "cell"
    
    // 7ee4b2d2f1c34725ab49be985438408c

    override func viewDidLoad() {
        super.viewDidLoad()
                
        tableView.register(NewsFeedTableViewCell.self, forCellReuseIdentifier: NewsFeedsVC.cellIdentifier)
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        
    }
    

    
    
    // https://newsapi.org/v2/everything?q=bitcoin&from=2019-03-29&sortBy=publishedAt&apiKey=7ee4b2d2f1c34725ab49be985438408c


}


/// MARK: UITableView DataSources
extension NewsFeedsVC {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: NewsFeedsVC.cellIdentifier, for: indexPath) as! NewsFeedTableViewCell
        
        cell.newsImage.image = #imageLiteral(resourceName: "Namo")
        cell.newsTitle.text = "40 TMC MLAs in touch with me: PM Modi makes sensational claim in West Bengal"
        cell.date.text = "Apr 29, 2019"
        cell.time.text = "11:23"
        cell.newsDetail.text = """
Prime Minister Narendra Modi claimed on Monday that 40 TMC MLAs were in touch with him and will desert their party once the BJP wins the general elections. He also accused TMC supremo Mamata Banerjee of nepotism, insisting she wants to politically establish her nephew in West Bengal. Modi also assailed her over her prime ministerial ambitions, saying "Didi, Dilli door hai (Delhi is far away for you). "Forty TMC MLAs are in touch with me and all your MLAs will desert you once the BJP wins the elections. Political ground has slipped from under your feet," Modi told an election rally in Sreerampur, targeting the West Bengal chief minister.
"""

        return cell
    }
    
}

/// MARK: UITableView Delegate
extension NewsFeedsVC {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("hi \(indexPath.row)")
    }
    

    
}




/// NewsFeedTableViewCell
class NewsFeedTableViewCell: UITableViewCell {
    
    var newsImage = UIImageView()
    var newsTitle =  UILabel()
    var newsDetail =  UILabel()
    var date =  UILabel()
    var time =  UILabel()
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init (coder:)")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        uiSetup()

        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func uiSetup()  {
        
        self.addSubview(newsImage)
        newsImage.clipsToBounds = true
        newsImage.contentMode = .scaleAspectFill
        newsImage.translatesAutoresizingMaskIntoConstraints = false
        
        newsImage.topAnchor.constraint(equalTo: self.topAnchor, constant: 5).isActive = true
        newsImage.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 5).isActive = true
        newsImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5).isActive = true
        newsImage.widthAnchor.constraint(equalToConstant: 100).isActive = true
        newsImage.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        self.addSubview(newsTitle)
        newsTitle.translatesAutoresizingMaskIntoConstraints = false
        newsTitle.numberOfLines = 0
        newsTitle.topAnchor.constraint(equalTo: self.topAnchor, constant: 5).isActive = true
        newsTitle.leadingAnchor.constraint(equalTo: newsImage.leadingAnchor, constant: 5).isActive = true
        newsTitle.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5).isActive = true
        newsTitle.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        self.addSubview(newsDetail)
        newsDetail.numberOfLines = 0
        newsDetail.translatesAutoresizingMaskIntoConstraints = false
        newsDetail.topAnchor.constraint(equalTo: newsTitle.bottomAnchor, constant: 5).isActive = true
        newsDetail.bottomAnchor.constraint(equalTo: date.topAnchor, constant: 5).isActive = true
        newsDetail.leadingAnchor.constraint(equalTo: newsImage.leadingAnchor, constant: -2).isActive = true
        newsDetail.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5).isActive = true
        newsDetail.heightAnchor.constraint(equalToConstant: 100).isActive = true

        

        
        self.addSubview(date)
        date.translatesAutoresizingMaskIntoConstraints = false
        date.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 5).isActive = true
        date.leadingAnchor.constraint(equalTo: newsImage.leadingAnchor, constant: 5).isActive = true
        date.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5).isActive = true
        date.heightAnchor.constraint(equalToConstant: 12).isActive = true
        
        self.addSubview(time)
        time.translatesAutoresizingMaskIntoConstraints = false
        time.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 5).isActive = true
        time.leadingAnchor.constraint(equalTo: date.leadingAnchor, constant: -2).isActive = true
        time.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5).isActive = true
        time.heightAnchor.constraint(equalToConstant: 12).isActive = true
        
    
        
    }
    
}
