//
//  SelectedBoardVC1.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class SelectedBoardVC1: UIViewController {
    
    @IBOutlet var animatedView: UIView!
    @IBOutlet weak var textEditorImageView: UIImageView!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    
    var effect: UIVisualEffect!
    
    @IBOutlet weak var selectedCollectionView: UICollectionView! {
        didSet {
            
            selectedCollectionView.delegate = self
            selectedCollectionView.dataSource = self
            selectedCollectionView.isScrollEnabled = false
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        effect = visualEffectView.effect
        visualEffectView.effect = nil
        
        animatedView.layer.cornerRadius = 5
        
        
        let viewWidth = UIScreen.main.bounds.width
        let viewHeight = UIScreen.main.bounds.height
        let layout = UICollectionViewFlowLayout()
        self.selectedCollectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: viewWidth/4 - 2, height: viewHeight/4 - 2)
        layout.minimumInteritemSpacing = 2
        layout.minimumLineSpacing = 2
        selectedCollectionView.collectionViewLayout = layout
        selectedCollectionView.reloadData()
        
        let openTextEditorTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openTextEditor(tapGestureRecognizer:)))
        textEditorImageView.isUserInteractionEnabled = true
        textEditorImageView.addGestureRecognizer(openTextEditorTapGestureRecognizer)

    }
    
    
    // add board gesture defination
    @objc func openTextEditor(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "ShowTextEditor", sender: self)
     
    }
    
    func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        
        return true
    }
    
    private func animateIn() {
        
        self.view.addSubview(animatedView)
        animatedView.center = self.selectedCollectionView.center
        animatedView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        animatedView.alpha = 0
        
        UIView.animate(withDuration: 0.4) {
            self.visualEffectView.effect = self.effect
            self.animatedView.alpha = 1
            self.animatedView.transform = CGAffineTransform.identity
        }
        
    }


}


extension SelectedBoardVC1 : UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 16
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newCell", for: indexPath) as! SelectedBoardCollectionViewCell
        cell.backgroundColor = .red
        cell.layer.cornerRadius = 8
        return cell
    }
    
    
    
}


extension SelectedBoardVC1: UICollectionViewDelegate {
    
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    
            let cell = collectionView.cellForItem(at: indexPath) as! SelectedBoardCollectionViewCell
    
    
            for subview in cell .subviews
            {
                if let item = subview as? UIImageView
                {
    
                    print("imageview")
                }
                else if let item = subview as? UITextView {
    
                    print("UITextView")
    
    
    
                } else if let item = subview as? UIView {
                    
                    animateIn()
    
                    print("UIView")
        
                }
            }
        }
    
}
