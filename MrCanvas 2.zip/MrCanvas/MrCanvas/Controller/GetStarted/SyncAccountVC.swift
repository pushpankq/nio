//
//  LoginVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import ZVProgressHUD

class SyncAccountVC: UIViewController {
    
    
    /// IBOutlets
    @IBOutlet var alertMessageLabel: UILabel!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var loginCredentialContainerView: UIView!
    
    // MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        self.uiSetup()
        
    }
    

    // MARK: IBActions
    // Skip the login and signup functionality
    @IBAction func tryItFirstButtonPressed(_ sender: UIButton) {
        
        
        AlertController.sharedInstance.showAlertView(title: "Mr Canvas ", message: "Feature is under development", actionTitles: ["OK"], actions: nil)
//        Helper.saveUserDefault(key: "userToken", value: "1")
//        self.performSegue(withIdentifier: Constants.Storyboard.Identifier.kDashboardIdentifier, sender: self)
    }
    
    // Login the use
    @IBAction func loginButtonPressed(_ sender: UIButton) {
        
        getData(operationType: OperationType.Login.rawValue)
    }

    
    @IBAction func signUpButtonPressed(_ sender: UIButton) {
        getData(operationType: OperationType.SignUp.rawValue)
    }



    /// user gets data if he is login or signing up
    ///
    /// - Parameter operationType: Operation Type enum (SignUp, Login)
    func getData(operationType:String)  {
        
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text
        let syncAccountModel = SyncAccountModel(email: email!, password: password!)
        let isValid = syncAccountModel.loginFormValidate()
        if !isValid {
            
            alertMessageLabel.isHidden = false
            emailTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            passwordTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            
        } else {
            
            ZVProgressHUD.animationType = .native
            ZVProgressHUD.show(with: "Loading...", in: self.view, delay: 0.0)
            let syncAccountModel = SyncAccountModel(email: email!, password: password!)
            syncAccountModel.userLogin(operationType) { (isSuccess) in
                
                if isSuccess {
                ZVProgressHUD.dismiss()
                    DispatchQueue.main.async {
                        
                        self.performSegue(withIdentifier: Constants.Storyboard.Identifier.kDashboardIdentifier, sender: self)

                    }
            } else {
                ZVProgressHUD.showError(with: syncAccountModel.alertMessage)
            }
        }
    }
}

    func uiSetup()  {
        
        loginCredentialContainerView.layer.borderColor = UIColor.lightGray.cgColor
        loginCredentialContainerView.layer.borderWidth = 2
        emailTextField.keyboardType = .emailAddress
        passwordTextField.keyboardType = .default
        passwordTextField.isSecureTextEntry = true
        alertMessageLabel.isHidden = true
        alertMessageLabel.font = UIFont(name: alertMessageLabel.font.fontName, size: 14)
        alertMessageLabel.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
    }
    
}

//
//
//
//
//

// TextField Delegate handle
extension SyncAccountVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        getData(operationType: "")
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        emailTextField.textColor = .black
        passwordTextField.textColor = .black
        return true
    }
}
