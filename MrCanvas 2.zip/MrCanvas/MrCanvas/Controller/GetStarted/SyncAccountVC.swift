//
//  LoginVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import ZVProgressHUD

class SyncAccountVC: UIViewController {
    
    @IBOutlet var alertMessageLabel: UILabel!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var loginCredentialContainerView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        self.uiSetup()
        
    }
    
    func uiSetup()  {
        
        loginCredentialContainerView.layer.borderColor = UIColor.lightGray.cgColor
        loginCredentialContainerView.layer.borderWidth = 2
        emailTextField.keyboardType = .emailAddress
        passwordTextField.keyboardType = .default
        passwordTextField.isSecureTextEntry = true
        alertMessageLabel.isHidden = true
        alertMessageLabel.font = UIFont(name: alertMessageLabel.font.fontName, size: 14)
        alertMessageLabel.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
        
    }

    @IBAction func tryItFirstButtonPressed(_ sender: UIButton) {
        
        Helper.saveUserDefault(key: "userToken", value: "1")
        self.performSegue(withIdentifier: "DashboardID", sender: self)
    }
    
    
    @IBAction func loginButtonPressed(_ sender: UIButton) {
        
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text
        
        let syncAccountModel = SyncAccountModel(email: email!, password: password!)
        let isValid = syncAccountModel.loginFormValidate()
        
        if !isValid {
            
            alertMessageLabel.isHidden = false
            emailTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            passwordTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            
        } else  {
            
            ZVProgressHUD.animationType = .native
            ZVProgressHUD.show(with: "Loading...", in: self.view, delay: 0.0)
            
            let syncAccountModel = SyncAccountModel(email: email!, password: password!)
            syncAccountModel.userLogin{(error) in
                
                if error == nil {
                    ZVProgressHUD.dismiss()
                    self.performSegue(withIdentifier: "DashboardID", sender: self)
                } else {
                    ZVProgressHUD.showError(with: error!)
                }
            }
            alertMessageLabel.isHidden = true
        }
    }

    
    @IBAction func signUpButtonPressed(_ sender: UIButton) {
        
       callSyncAccountModel()
        
    }
    
    func callSyncAccountModel()  {
        
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text
        
        let syncAccountModel = SyncAccountModel(email: email!, password: password!)
        let isValid = syncAccountModel.loginFormValidate()
        
        if !isValid {
            
            alertMessageLabel.isHidden = false
            emailTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            passwordTextField.textColor = UIColor.init(red: 255/255, green: 41/255, blue: 48/255, alpha: 1)
            
        } else  {
            
            ZVProgressHUD.animationType = .native
            ZVProgressHUD.show(with: "Loading...", in: self.view, delay: 0.0)

            let syncAccountModel = SyncAccountModel(email: email!, password: password!)
            syncAccountModel.userSignUp{(error) in
                
                if error == nil {
                    ZVProgressHUD.dismiss()
                    self.performSegue(withIdentifier: "DashboardID", sender: self)
                } else {
                    ZVProgressHUD.showError(with: error!)
                }
            }
            alertMessageLabel.isHidden = true
        }
    }
}


extension SyncAccountVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        callSyncAccountModel()
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        emailTextField.textColor = .black
        passwordTextField.textColor = .black
        return true
    }
}
