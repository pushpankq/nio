//
//  PresentVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class PresentVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
