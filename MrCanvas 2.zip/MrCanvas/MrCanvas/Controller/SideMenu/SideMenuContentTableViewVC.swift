//
//  SideMenuContentTableViewVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import SideMenu
import ZVProgressHUD

class SideMenuContentTableViewVC: UIViewController {

    
    let sideMenuDataModel: [SideMenuDataModel] = [SideMenuDataModel(headerTitle: "Home", sideMenuItems:               ["Home"], hederTitleImage: #imageLiteral(resourceName: "account")),
                                                   SideMenuDataModel(headerTitle: "Help", sideMenuItems: ["Welcome Guide", "Getting Started", "Support"], hederTitleImage: #imageLiteral(resourceName: "help")),
                                                   SideMenuDataModel(headerTitle: "Shop", sideMenuItems: ["Basic", "Premium"], hederTitleImage: #imageLiteral(resourceName: "shop")),
                                                   SideMenuDataModel(headerTitle: "Contact", sideMenuItems: ["Rate MrCanvas", "Follow on Twitter", "Send us Feedback", "Read our Blog"], hederTitleImage:#imageLiteral(resourceName: "contact")),
                                                   SideMenuDataModel(headerTitle: "Logout", sideMenuItems: ["Logout"], hederTitleImage:#imageLiteral(resourceName: "contact")),
                                                   ]


    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        self.tableView.separatorStyle = .none
        self.tableView.showsHorizontalScrollIndicator = false
        self.tableView.showsVerticalScrollIndicator = false

    }
}

extension SideMenuContentTableViewVC: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sideMenuDataModel.count
    }
    

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sideMenuDataModel[section].headerTitle
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (sideMenuDataModel[section].sideMenuItems?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row]
        cell?.textLabel?.textColor = UIColor.init(red: 252/255, green: 111/255, blue: 10/255, alpha: 1)
        return cell!
    }
    
}

extension SideMenuContentTableViewVC : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: tableView.bounds.origin.y, width: tableView.frame.width, height: 50))
        headerView.backgroundColor = .white

        let headerTitle = UILabel()
        headerTitle.frame = CGRect.init(x: 55, y: 2, width: headerView.frame.width-10, height: 40)
        headerView.addSubview(headerTitle)
        headerTitle.text = sideMenuDataModel[section].headerTitle
        headerTitle.textColor = .black
        
        let headerIcon = UIImageView()
        headerIcon.frame = CGRect.init(x: 5, y: 5, width: 30, height:30)
        headerView.addSubview(headerIcon)
        headerIcon.clipsToBounds = true
        headerIcon.contentMode = .scaleAspectFit
        headerIcon.image = sideMenuDataModel[section].hederTitleImage
        return headerView
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] == "Logout" {
            
            let alertController = UIAlertController(title: "Sign Out", message: "Are you sure you want to sign out?", preferredStyle: .alert)
            let yesAction = UIAlertAction(title: "Yes", style: .default) { (yesAction) in
                
                ZVProgressHUD.animationType = .native
                ZVProgressHUD.show(with: "Loading...", in: self.view, delay: 0.0)

                
                let sideMenuModel = SideMenuModel()
                sideMenuModel.userSignOut(completionHandler: { (isSuccess) in
                    
                    if isSuccess {
                        ZVProgressHUD.dismiss()
                        
                        Helper.removeUserDefault(key: "userToken")
                        Helper.removeUserDefault(key: "userId")
                        Helper.removeUserDefault(key: "emailId")
                        
                        self.dismiss(animated: true, completion: nil)
                        methodForPopViewController(viewController: DashboardVC.self, navigation: self.navigationController!)
                        
                        DispatchQueue.main.async {
                            
                            let syncAccountVC = UIStoryboard(name: Constants.Storyboard.main, bundle: nil).instantiateViewController(withIdentifier: "SyncAccountVC")
                            self.navigationController?.pushViewController(syncAccountVC, animated: true)
                            
                        }
                        
                    } else {
                        
                        ZVProgressHUD.showError(with: sideMenuModel.alertMessage)
                        
                    }
                    print("hi")
                })
                // yes here...
            }
            
            let noAction = UIAlertAction(title: "No", style: .default) { (noAction) in
                // no action
            }
            
            
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
            
            self.present(alertController, animated: true, completion: nil)
            
            
         } else {

            self.dismiss(animated: true, completion: nil)
            methodForPopViewController(viewController: DashboardVC.self, navigation: self.navigationController!)
        
        
        if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] ==  "Getting Started" {
            let getStartedVC = Constants.mainStoryBoard.instantiateViewController(withIdentifier: "GetStartedVC")
            self.navigationController?.pushViewController(getStartedVC, animated: true)
        }
            
        else if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] ==  "Home" {
            self.performSegue(withIdentifier: Constants.Storyboard.Identifier.kDashboardIdentifierSecond, sender: self)
        }

        else if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] ==  "Read our Blog" {
            self.performSegue(withIdentifier: "SHowIt", sender: self)
        }
        else if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] ==  "Basic" {
            self.performSegue(withIdentifier: "shopBasicID", sender: self)
        }
            
        else if sideMenuDataModel[indexPath.section].sideMenuItems![indexPath.row] ==  "Premium" {
            self.performSegue(withIdentifier: "shopPremiumID", sender: self)
        }
        
        
        else {
            
//            let url = NSURL(string: "https://google.com")!
//            UIApplication.shared.openURL(url as URL)
        }
        }
    }
 
}
