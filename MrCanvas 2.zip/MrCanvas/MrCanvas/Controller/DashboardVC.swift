//
//  ScaleAnimationViewController.swift
//  Gemini
//
//  Created by shoheiyokoyama on 2017/06/28.
//  Copyright © 2017年 CocoaPods. All rights reserved.
//

import UIKit
import AnimatedCollectionViewLayout
import SideMenu

final class DashboardVC: UIViewController, ChildCollectionCellClass {
    
    var parentCollectionViewTitleArray = ["Welcome to MrCanvas ","Unnamed"];
    
    @IBOutlet weak var addBoardImageView: UIImageView!
    @IBOutlet weak var deleteBoardImageView: UIImageView!
    @IBOutlet weak var sideMenuImageView: UIImageView!
    
    @IBOutlet weak var collectionView: UICollectionView! {
        
        didSet {
            collectionView.delegate = self
            collectionView.dataSource = self
            
        }
    }
    
    
    var selectedIndex = 0
//    var expanded = false
    
    // set cell identifier
    fileprivate let cellIdentifier = "ParentCollectionViewCell"
    // set scrolling direction
    private(set) var scrollDirection: UICollectionView.ScrollDirection = .horizontal

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.setupSideMenu()
        self.collectionViewLayoutSetup()
        self.addGesture()
    }
    
    /// collection View layout Setup
    /// layuot animation is card type
    private func collectionViewLayoutSetup() {
        
        let layout = AnimatedCollectionViewLayout()
        layout.animator = LinearCardAttributesAnimator(minAlpha: 0.5, itemSpacing: 0.01, scaleRate: 1)
        layout.itemSize = CGSize(width: view.frame.size.width - 40, height: view.frame.size.height-100)

        layout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = layout
        collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
        
    }
    
    
    
    /// add all gesture
    private func addGesture() {
        
        // delete board tap gesture
        let deleteBoardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(deleteBoard(tapGestureRecognizer:)))
        deleteBoardImageView.isUserInteractionEnabled = true
        deleteBoardImageView.addGestureRecognizer(deleteBoardTapGestureRecognizer)
        
        // add board tap gesture
        let addBoardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addBoard(tapGestureRecognizer:)))
        addBoardImageView.isUserInteractionEnabled = true
        addBoardImageView.addGestureRecognizer(addBoardTapGestureRecognizer)
        
        // add board tap gesture
        let sideMenuTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(sideMenu(tapGestureRecognizer:)))
        sideMenuImageView.isUserInteractionEnabled = true
        sideMenuImageView.addGestureRecognizer(sideMenuTapGestureRecognizer)
    }
    
    
    /// side menu setup, drawer width change, blur effect change
    private func setupSideMenu() {
        
        SideMenuManager.default.menuLeftNavigationController = storyboard!.instantiateViewController(withIdentifier: "LeftMenuNavigationController") as? UISideMenuNavigationController
        SideMenuManager.default.menuWidth = UIScreen.main.bounds.width/1.25
        SideMenuManager.default.menuPresentMode = .menuSlideIn
        SideMenuManager.default.menuAnimationFadeStrength = 0.5
        SideMenuManager.default.menuParallaxStrength = 1

        
    }

    
    // delete board gesture defination
    @objc func deleteBoard(tapGestureRecognizer: UITapGestureRecognizer) {
        
        let title = "Delete Depex Technologies ?"
        let alertController = UIAlertController(title: title, message: "This will parmanently delete the Board", preferredStyle: .alert)
        
        let cancelAlertAction = UIAlertAction(title: "Cancle", style: .default, handler: nil)
        let deleteAlertAction = UIAlertAction(title: "Delete", style: .default) { _ in
            
            self.parentCollectionViewTitleArray.remove(at: self.selectedIndex)
            self.collectionView.reloadData()
        }
        
        alertController.addAction(cancelAlertAction)
        alertController.addAction(deleteAlertAction)
        
        self.present(alertController, animated: true, completion: nil)

    }
    
    
    
    
    // add board gesture defination
    @objc func addBoard(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.parentCollectionViewTitleArray.append("Unnamed")
        self.collectionView.reloadData()
    }
    
    
    @objc func sideMenu(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "showSideMenu", sender: self)
 
    }
    
    // add board gesture defination
    @objc func showFullScreen(tapGestureRecognizer: UITapGestureRecognizer) {

        print("full screen ")
  
    }
    
    @objc func changeTitle(sender : UIButton){
        
        if let title = sender.titleLabel?.text {
            
            self.changeCellTitle(title: title, index: sender.tag)
        }
    }
    
    func changeSize() {

        
        self.performSegue(withIdentifier: "showBoard", sender: self)

    }
    


    
    
    func changeCellTitle(title: String, index: Int) {
        
        let alertController = UIAlertController(title: "", message: "Change Title", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default) { (action) in
            
            let textField = alertController.textFields![0]
            guard let textfieldText = textField.text else {
                
                return
            }
            
            self.parentCollectionViewTitleArray[index] = textfieldText
            self.collectionView.reloadData()

        }
        
        alertController.addTextField { (textfield) in
            textfield.text = title
        }
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }

}



// MARK: - UIScrollViewDelegate
extension DashboardVC {

    
    
    // get collection view index on scrolling
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var visibleRect = CGRect()
        
        visibleRect.origin = collectionView.contentOffset
        visibleRect.size = collectionView.bounds.size
        
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        guard let indexPath = collectionView.indexPathForItem(at: visiblePoint) else { return }
        
        selectedIndex = indexPath.row
        
        DispatchQueue.main.async {
            self.collectionView.reloadData()
            
        }
        print("index is ", selectedIndex)
    }
    
   
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        DispatchQueue.main.async {
            self.collectionView.reloadData()

        }
        
       
    }

}



// MARK: - UICollectionViewDataSource
extension DashboardVC: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return parentCollectionViewTitleArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! ParentCollectionViewCell
        cell.configure(with: parentCollectionViewTitleArray[indexPath.row])
        cell.buttonTitle.tag = indexPath.row
        cell.buttonTitle.addTarget(self, action: #selector(changeTitle), for: .touchUpInside)
        cell.delegate = self
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        
        return cell

    }
}

// MARK: - UICollectionViewDelegate
extension DashboardVC: UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

//        self.expanded = true

        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.9, initialSpringVelocity: 0.9, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            self.collectionView.reloadItems(at: [indexPath])
            self.collectionView.delegate = self
        }, completion: { success in
            print("success")
        })
    }
}

//extension UICollectionViewFlowLayout {
//
//    var collectionViewWidthWithoutInsets: CGFloat {
//        get {
//            guard let collectionView = self.collectionView else { return 0 }
//            let collectionViewSize = collectionView.bounds.size
//            let widthWithoutInsets = collectionViewSize.width
//                - self.sectionInset.left - self.sectionInset.right
//                - collectionView.contentInset.left - collectionView.contentInset.right
//            return widthWithoutInsets
//        }
//    }
//
//}



