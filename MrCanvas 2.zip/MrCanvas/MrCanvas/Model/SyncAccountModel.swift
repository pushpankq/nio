//
//  LoginModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import SwiftyJSON

class SyncAccountModel {
    
    // Completion Handler
    typealias registrationData = (String?) -> Void
    typealias loginData = (String?) -> Void
    
    var alertMessage: String
    var email: String
    var password: String
    var successBool = false
    var requestData = [String:Any]()
    
    
    init(email: String, password: String) {
        
        self.email = email
        self.password = password
        self.alertMessage = ""
    }
    
    /// Login form Validation
    ///
    /// - Returns: form is valid or not
    func loginFormValidate() -> Bool {
        
        if email.isEmpty || password.isEmpty ||  !isValidEmail( emailString: email) {
            
            alertMessage = Constants.Validation.emailOrPasswordErrorMessage
            return false
        }
        return true
    }
    

    /// Accessing data from Login web api
    ///
    /// - Parameter completionHandler: using callback to send data in controller
    func userLogin(completionHandler: @escaping loginData)  {

        let url = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.loginUser
        let requestData = createRequestData(isLogin: true)
        
        var loginDataDict = [String: Any]()
        loginDataDict["RequestData"] = requestData
        
        APIManager.shared.postService(url, andParameter: loginDataDict) { (json, error) in
            
            if error == nil {
                guard let jsonData = json else {
                    return
                }
                
                if jsonData["successBool"].boolValue {
                    
                    self.getDataFromService(jsonData: jsonData)
                    completionHandler(nil)
                    
                } else {
                    
                    let errorMessage = jsonData["ErrorObj"]["ErrorMsg"].stringValue
                    print("error \(errorMessage)")
                    completionHandler(errorMessage)
                }
            } else {
                
                completionHandler(error?.localizedDescription)
            }
        }

    }
    
    
    /// Accessing data from User SignUp web api
    ///
    /// - Parameter completionHandler: using callback to send data in controller
    func userSignUp(completionHandler: @escaping registrationData) {
        
        let url = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.createUser
        let requestData = createRequestData(isLogin: false)

        var registerDataDict = [String: Any]()
        registerDataDict["RequestData"] = requestData
        
        APIManager.shared.postService(url, andParameter: registerDataDict) { (json, error) in
            
            if error == nil {
                guard let jsonData = json else {
                    return
                }
                
                if jsonData["successBool"].boolValue {
                    
                    self.getDataFromService(jsonData: jsonData)
                    completionHandler(nil)
                } else {
                    
                    let errorMessage = jsonData["ErrorObj"]["ErrorMsg"].stringValue
                    completionHandler(errorMessage)
                }
            } else {
                
                completionHandler(error?.localizedDescription)
            }
        }
    }
    
    
    /// filter json data and save it user preferences
    ///
    /// - Parameter jsonData: json data which is return by the api
    func getDataFromService(jsonData: JSON) {
        
        let userToken = jsonData["response"]["userToken"].stringValue
        let userId = jsonData["response"]["user_id"].stringValue
        let emailId = jsonData["response"]["email"].stringValue
        
        Helper.saveUserDefault(key: "userToken", value: userToken)
        Helper.saveUserDefault(key: "userId", value: userId)
        Helper.saveUserDefault(key: "emailId", value: emailId)
        
    }
    
    /// Creating request body for accessing the web api
    ///
    /// - Parameter isLogin: if isLogin is true, we are using the request body for user login api otherwise for user SignUp api
    /// - Returns: Request body
    func createRequestData(isLogin:Bool) -> [String:Any] {
        
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kDeviceType] = Constants.ApiKeysValues.iOS
        requestData[Constants.ApiKeys.kDeviceID] = "fdgf"
        requestData[Constants.ApiKeys.kDeviceToken] = "fdgf"
        requestData[Constants.ApiKeys.kEmail] = email
        requestData[Constants.ApiKeys.kPassword] = password
        
        if !isLogin {
            requestData[Constants.ApiKeys.kUsername] = email
        }
        return requestData
    }
   
}
