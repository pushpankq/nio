//
//  LoginModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 10/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation


struct LoginModel : Codable {
    let successBool : Bool?
    let responseType : String?
    let successCode : String?
    let response : LoginResponse?
    let errorObj : ErrorObj?
    
    enum CodingKeys: String, CodingKey {
        
        case successBool = "successBool"
        case responseType = "responseType"
        case successCode = "successCode"
        case response = "response"
        case errorObj = "ErrorObj"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        successBool = try values.decodeIfPresent(Bool.self, forKey: .successBool)
        responseType = try values.decodeIfPresent(String.self, forKey: .responseType)
        successCode = try values.decodeIfPresent(String.self, forKey: .successCode)
        response = try values.decodeIfPresent(LoginResponse.self, forKey: .response)
        errorObj = try values.decodeIfPresent(ErrorObj.self, forKey: .errorObj)
    }
}


struct LoginResponse : Codable {
    let message : String?
    let user_id : Int?
    let username : String?
    let userToken : String?
    let email : String?
    let device_token : String?
    let device_type : String?
    
    enum CodingKeys: String, CodingKey {
        
        case message = "message"
        case user_id = "user_id"
        case username = "username"
        case userToken = "userToken"
        case email = "email"
        case device_token = "device_token"
        case device_type = "device_type"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        user_id = try values.decodeIfPresent(Int.self, forKey: .user_id)
        username = try values.decodeIfPresent(String.self, forKey: .username)
        userToken = try values.decodeIfPresent(String.self, forKey: .userToken)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        device_token = try values.decodeIfPresent(String.self, forKey: .device_token)
        device_type = try values.decodeIfPresent(String.self, forKey: .device_type)
    }
    
}
