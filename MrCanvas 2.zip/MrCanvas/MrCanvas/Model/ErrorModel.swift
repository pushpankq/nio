//
//  ErrorModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 10/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation


struct ErrorModel : Codable {
    let successBool : Bool?
    let successCode : String?
    let response : [String]?
    let errorObj : ErrorObj?
    
    enum CodingKeys: String, CodingKey {
        
        case successBool = "successBool"
        case successCode = "successCode"
        case response = "response"
        case errorObj = "ErrorObj"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        successBool = try values.decodeIfPresent(Bool.self, forKey: .successBool)
        successCode = try values.decodeIfPresent(String.self, forKey: .successCode)
        response = try values.decodeIfPresent([String].self, forKey: .response)
        errorObj = try values.decodeIfPresent(ErrorObj.self, forKey: .errorObj)
    }
    
}


struct ErrorObj : Codable {
    let errorCode : String?
    let errorMsg : String?
    
    enum CodingKeys: String, CodingKey {
        
        case errorCode = "ErrorCode"
        case errorMsg = "ErrorMsg"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        errorCode = try values.decodeIfPresent(String.self, forKey: .errorCode)
        errorMsg = try values.decodeIfPresent(String.self, forKey: .errorMsg)
    }
    
}
