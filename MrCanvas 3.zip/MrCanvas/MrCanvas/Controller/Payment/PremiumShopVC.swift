//
//  PremiumShopVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import SideMenu

class PremiumShopVC: UIViewController {

    @IBOutlet weak var sideMenuImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let sideMenuTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(sideMenu(tapGestureRecognizer:)))
        sideMenuImageView.isUserInteractionEnabled = true
        sideMenuImageView.addGestureRecognizer(sideMenuTapGestureRecognizer)
        
        setupSideMenu()

        // Do any additional setup after loading the view.
    }


    
    
    /// side menu setup, drawer width change, blur effect change
    private func setupSideMenu() {
        
        SideMenuManager.default.menuLeftNavigationController = storyboard!.instantiateViewController(withIdentifier: "LeftMenuNavigationController") as? UISideMenuNavigationController
        SideMenuManager.default.menuWidth = UIScreen.main.bounds.width/1.25
        SideMenuManager.default.menuPresentMode = .menuSlideIn
        SideMenuManager.default.menuAnimationFadeStrength = 0.5
        SideMenuManager.default.menuParallaxStrength = 1
        
    }
    
    @objc func sideMenu(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "showSideMenu", sender: self)
        
    }

    
    //showSideMenu

}
