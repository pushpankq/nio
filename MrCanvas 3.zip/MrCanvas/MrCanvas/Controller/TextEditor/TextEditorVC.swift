//
//  TextEditorVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

class TextEditorVC: UIViewController {
    
    
    //    MARK: IBOutlets
    @IBOutlet weak var dottedLineView: UIView!
    @IBOutlet weak var notesAttachmentView: UIView!
    @IBOutlet weak var visualBlurEffect: UIVisualEffectView!
    @IBOutlet weak var pickerBackgroundView: UIView!
    @IBOutlet weak var alignmentpickerView: UIView!
    @IBOutlet weak var textSizePickerView: UIView!
    @IBOutlet weak var colorPickerView: UIView!
    @IBOutlet weak var blackTextButton: UIButton!
    @IBOutlet weak var whiteTextButton: UIButton!
    @IBOutlet weak var blueTextButton: UIButton!
    @IBOutlet weak var greenTextButton: UIButton!
    @IBOutlet weak var yellowTextButton: UIButton!
    @IBOutlet weak var redTextButton: UIButton!
    @IBOutlet weak var brownTextButton: UIButton!
    @IBOutlet weak var voiletTextButton: UIButton!
    @IBOutlet weak var grayTextButton: UIButton!
    @IBOutlet weak var cyanTextButton: UIButton!
    @IBOutlet weak var leftTextAlignButton: UIButton!
    @IBOutlet weak var centerAlignButton: UIButton!
    @IBOutlet weak var rightTextAlignButton: UIButton!
    @IBOutlet weak var topTextAlignButton: UIButton!
    @IBOutlet weak var bottomTextAlignButton: UIButton!
    @IBOutlet weak var centerTextAlignButton: UIButton!
    @IBOutlet weak var largeTextButton: UIButton!
    @IBOutlet weak var mediumTextButton: UIButton!
    @IBOutlet weak var smallTextButton: UIButton!
    @IBOutlet weak var textAlignmentImageView: UIImageView!
    @IBOutlet weak var dismissKeyboardImageView: UIImageView!
    @IBOutlet weak var textSizeImageView: UIImageView!
    @IBOutlet weak var colorPickerImageView: UIImageView!
    @IBOutlet weak var shareANotes: UIImageView!
    
    
    @IBOutlet weak var messageTextField: UITextField!
//    @IBOutlet weak var textMessageView: UITextView!
    
    
    @IBOutlet weak var blackBGButton: UIButton!
    @IBOutlet weak var whiteBGButton: UIButton!
    @IBOutlet weak var blueBGButton: UIButton!
    @IBOutlet weak var greenBGButton: UIButton!
    @IBOutlet weak var yellowBGColor: UIButton!
    @IBOutlet weak var redBGButton: UIButton!
    @IBOutlet weak var brownBGButton: UIButton!
    @IBOutlet weak var voiletBGButton: UIButton!
    @IBOutlet weak var grayBGButton: UIButton!
    @IBOutlet weak var cyanBGButton: UIButton!
    
    lazy var xAlign: String = String()
    lazy var yAlign: String = String()
    lazy var setTextinCollectionView = UIImageView()
    lazy var attachATextFileImageView = UIImageView()
    var effect: UIVisualEffect!
    
    /// MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        IQKeyboardManager.sharedManager().enable = false

        
        self.visualBlurEffect.isHidden = true
        alignmentpickerView.layer.cornerRadius = 2
        messageTextField.text = ""
//        messageTextField.delegate = self

        drawDottedLine(start: CGPoint(x: dottedLineView.bounds.minX, y: dottedLineView.bounds.minY), end: CGPoint(x: dottedLineView.bounds.maxX, y: dottedLineView.bounds.minY), view: dottedLineView)
        
        setTextinCollectionView.image = UIImage(named: "HalfSquare")
        self.view.addSubview(setTextinCollectionView)
        setTextinCollectionView.contentMode = .scaleAspectFit
        setTextinCollectionView.clipsToBounds = true
        setTextinCollectionView.isHidden = true
        
        attachATextFileImageView.image = UIImage(named: "HalfSquareRotate")
        self.view.addSubview(attachATextFileImageView)
        attachATextFileImageView.contentMode = .scaleAspectFit
        attachATextFileImageView.clipsToBounds = true
        attachATextFileImageView.isHidden = true
        
        let gesture = UITapGestureRecognizer(target: self, action:  #selector(self.removeAllView))
        self.view.addGestureRecognizer(gesture)

        let dismissKeyboardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard(tapGestureRecognizer:)))
        dismissKeyboardImageView.isUserInteractionEnabled = true
        dismissKeyboardImageView.addGestureRecognizer(dismissKeyboardTapGestureRecognizer)
        
        let changeTextAlignmentTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(changeTextAlignment(tapGestureRecognizer:)))
        textAlignmentImageView.isUserInteractionEnabled = true
        textAlignmentImageView.addGestureRecognizer(changeTextAlignmentTapGestureRecognizer)
        
        let changeTextSizeTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(changeTextSize(tapGestureRecognizer:)))
        textSizeImageView.isUserInteractionEnabled = true
        textSizeImageView.addGestureRecognizer(changeTextSizeTapGestureRecognizer)
        
        let changeTextColorTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(changeTextColor(tapGestureRecognizer:)))
        colorPickerImageView.isUserInteractionEnabled = true
        colorPickerImageView.addGestureRecognizer(changeTextColorTapGestureRecognizer)
        
        let setTextinCollectionViewColorTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(setText(tapGestureRecognizer:)))
        setTextinCollectionView.isUserInteractionEnabled = true
        setTextinCollectionView.addGestureRecognizer(setTextinCollectionViewColorTapGestureRecognizer)

        let attachATextFileTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(showAttachEditor(tapGestureRecognizer:)))
        attachATextFileImageView.isUserInteractionEnabled = true
        attachATextFileImageView.addGestureRecognizer(attachATextFileTapGestureRecognizer)
        
        let shareANotesTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(shareNotes(tapGestureRecognizer:)))
        shareANotes.isUserInteractionEnabled = true
        shareANotes.addGestureRecognizer(shareANotesTapGestureRecognizer)

        setSizes()
        
        xAlign = Constants.Alignment.center
        yAlign = Constants.Alignment.center
        textAlignment(xAlign:xAlign, yAlign:yAlign)

    }
    
    
    // add board gesture defination
    @objc func setText(tapGestureRecognizer: UITapGestureRecognizer) {
      
      let textEditorModel = TextEditorModel()
      textEditorModel.addTextEditorData(userId: "34", textAlignment: "left-center", textFontSize: "Big", bgColor: "#FFFF", textColor: "#0000", textViewText: "Hi My Name is Pushpank Kumar")
      
      
      
      // store data
      
//      {"RequestData":{"v_code":"1.0","apikey":"41bbf547d64c309749b613f16323b762","token":"6d99ab17d67e45c873a6937711baf1e6","userid":"5","board_id":"500","card_id":"9", "txt_alignment":"text-center", "txt_font_size":"12px", "txt_bg_color":"#ccc", "txt_color":"#000", "txt_comment":"Hi Mohit this testing for Mohit..."}}
      
      //  performSegue(withIdentifier: "unwindSegueToSelectedVC", sender: self)

    }
    
    // add board gesture defination
    @objc func showAttachEditor(tapGestureRecognizer: UITapGestureRecognizer) {
        
        showNotesAttachment()
        
    }
    
    // add board gesture defination
    @objc func shareNotes(tapGestureRecognizer: UITapGestureRecognizer) {
        
        let text = "This is the text....."
        let textShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textShare , applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    
    
    private func setSizes() {
        
        setTextinCollectionView.translatesAutoresizingMaskIntoConstraints = false
        setTextinCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8.0).isActive = true
        setTextinCollectionView.topAnchor.constraint(equalTo: view.topAnchor, constant: 10).isActive = true
        setTextinCollectionView.widthAnchor.constraint(equalToConstant: 40.0).isActive = true
        setTextinCollectionView.heightAnchor.constraint(equalToConstant: 40.0).isActive = true
        
        attachATextFileImageView.translatesAutoresizingMaskIntoConstraints = false
        attachATextFileImageView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10).isActive = true
        attachATextFileImageView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -10).isActive = true
        attachATextFileImageView.widthAnchor.constraint(equalToConstant: 40.0).isActive = true
        attachATextFileImageView.heightAnchor.constraint(equalToConstant: 40.0).isActive = true
    }
    

    

    @objc func removeAllView(sender : UITapGestureRecognizer) {
        
        messageTextField.becomeFirstResponder()
        
        self.alignmentpickerView.removeFromSuperview()
        self.textSizePickerView.removeFromSuperview()
        self.colorPickerView.removeFromSuperview()
        self.visualBlurEffect.isHidden = true
    
    }

    
    override func viewDidAppear(_ animated: Bool) {
        self.messageTextField.becomeFirstResponder()

    }
    
    // add board gesture defination
    @objc func dismissKeyboard(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.view.endEditing(true)
        self.pickerBackgroundView.isHidden = true
        setTextinCollectionView.isHidden = false
        attachATextFileImageView.isHidden = false
    }

}

//
//
//
//
//

// Change TextView Alignment

extension TextEditorVC: UITextViewDelegate {
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        dismissNotesAttachments()
        self.pickerBackgroundView.isHidden = false
        setTextinCollectionView.isHidden = true
        attachATextFileImageView.isHidden = true
        return true
    }
}


//
//
//
//
//

// Change TextView Alignment
extension TextEditorVC {
    
    @objc func changeTextAlignment(tapGestureRecognizer: UITapGestureRecognizer) {
        showTextAlignmentPickeView()
        
    }
    
    
    private func showTextAlignmentPickeView() {
        
        self.view.addSubview(alignmentpickerView)
        alignmentpickerView.frame = CGRect(x: 0, y: 5, width: self.view.frame.size.width, height: 50)
        alignmentpickerView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        alignmentpickerView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.visualBlurEffect.isHidden = false
            self.alignmentpickerView.alpha = 1
            self.alignmentpickerView.transform = CGAffineTransform.identity
        }
    }
    
    
    // Chane text alignment according to left side buttons
    @IBAction func xAlignButtonTapped(_ sender: UIButton) {
        
        let buttonArray = [leftTextAlignButton,centerAlignButton,rightTextAlignButton]
        
        buttonArray.forEach{
            
            $0?.isSelected = false
        }
        sender.isSelected = true
        
        if (sender.tag == 1) {
        
            xAlign = Constants.Alignment.left
        }
        else if (sender.tag == 2) {
            xAlign = Constants.Alignment.center
        }
        else if (sender.tag == 3) {
            xAlign = Constants.Alignment.right
        }
        
        self.textAlignment(xAlign: xAlign, yAlign: yAlign)
    }
    
    // Chane text alignment according to right side buttons
    @IBAction func yTextAlignTapped(_ sender: UIButton) {
        
        let buttonArray = [topTextAlignButton,centerTextAlignButton,bottomTextAlignButton]
        
        buttonArray.forEach{
            
            $0?.isSelected = false
        }
        
        sender.isSelected = true
        
        if (sender.tag == 4) {
            yAlign = Constants.Alignment.top
        }
        else if (sender.tag == 5) {
            yAlign = Constants.Alignment.center
        }
        else if (sender.tag == 6) {
            yAlign = Constants.Alignment.bottom
        }
        self.textAlignment(xAlign: xAlign, yAlign: yAlign)
        
    }
    
    // create combination of left side and right side buttons text alignment
//    func textAlignment(xAlign:String, yAlign:String)      // create combination of left side and right side buttons text alignment
    func textAlignment(xAlign:String, yAlign:String)  {
        
        if xAlign == Constants.Alignment.left && yAlign == Constants.Alignment.top {
            messageTextField.topLeftAlignment()
        }
        else if xAlign == Constants.Alignment.left && yAlign == Constants.Alignment.center {
            messageTextField.centerLeftAlignment()
        }
        else if xAlign == Constants.Alignment.left && yAlign == Constants.Alignment.bottom {
            messageTextField.bottomLeftAlighment()
        }
        else if xAlign == Constants.Alignment.center && yAlign == Constants.Alignment.top {
            messageTextField.centerTopAlign()
        }
        else if xAlign == Constants.Alignment.center && yAlign == Constants.Alignment.center {
            
            messageTextField.contentVerticalAlignment = .center
            messageTextField.contentHorizontalAlignment = .center
//            messageTextField.centerVertically()
            
//            textMessageView.addObserver(self, forKeyPath:"contentSize", options:.new, context:nil)

        }
        else if xAlign == Constants.Alignment.center && yAlign == Constants.Alignment.bottom {
            messageTextField.bottomCenterAlighment()
        }
        else if xAlign == Constants.Alignment.right && yAlign == Constants.Alignment.top {
            messageTextField.topRightAlignment()
        }
        else if xAlign == Constants.Alignment.right && yAlign == Constants.Alignment.center {
            messageTextField.centerRightAlignment()
        }
        else if xAlign == Constants.Alignment.right && yAlign == Constants.Alignment.bottom {
            messageTextField.bottomRightAlighment()
        }
    }
    
    func observeValueForKeyPath(keyPath: String, ofObject object: AnyObject, change: [NSObject:AnyObject], context: UnsafeMutableRawPointer) {
        if let textMessageView = object as? UITextView {
            var y: CGFloat = (textMessageView.bounds.size.height - textMessageView.contentSize.height * textMessageView.zoomScale)/2.0;
            if y < 0 {
                y = 0
            }
            textMessageView.contentOffset.y = -y
        }
    }
    
}

//
//
//
//
//

// Change TextView Text Size

extension TextEditorVC {
    
    // add board gesture defination
    @objc func changeTextSize(tapGestureRecognizer: UITapGestureRecognizer) {
        
        showTextSizePicker()
    }
    
    private func showTextSizePicker() {
        
        self.pickerBackgroundView.isHidden = true
        setTextinCollectionView.isHidden = false
        attachATextFileImageView.isHidden = false
        messageTextField.resignFirstResponder()
        
        self.view.addSubview(textSizePickerView)
        textSizePickerView.frame = CGRect(x: UIScreen.main.bounds.size.width - 155, y: 10, width: 150, height: 50)
        textSizePickerView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        textSizePickerView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.visualBlurEffect.isHidden = false
            self.textSizePickerView.alpha = 1
            self.textSizePickerView.transform = CGAffineTransform.identity
        }
    }
    

    
    /// Change TextView text font size
    ///
    /// - Parameter sender: seleted Button
    @IBAction func changeTextSize(_ sender: UIButton) {
        
        let buttonArray = [largeTextButton,mediumTextButton,smallTextButton]
        buttonArray.forEach{
            $0?.isSelected = false
        }
        sender.isSelected = true
        let fontSize = getFontSize(index: sender.tag)
        self.messageTextField.font = UIFont(name: messageTextField.font!.fontName, size: fontSize)

    }
}


//
//
//
//
//

// Change TextView colors


extension TextEditorVC {
    
    // add board gesture defination
    @objc func changeTextColor(tapGestureRecognizer: UITapGestureRecognizer) {
        showTextColorPicker()
    }
    
    private func showTextColorPicker() {
        
        self.view.addSubview(colorPickerView)
        colorPickerView.frame = CGRect(x: 0, y:30, width: UIScreen.main.bounds.size.width, height: 73)
        colorPickerView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        colorPickerView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.visualBlurEffect.isHidden = false
            self.colorPickerView.alpha = 1
            self.colorPickerView.transform = CGAffineTransform.identity
        }
    }
    
    /// It will change the textview text color
    ///
    /// - Parameter sender: tapped button
    @IBAction func textViewTextColorChange(_ sender: UIButton) {
        let buttonArray = [blackTextButton,whiteTextButton,blueTextButton,greenTextButton,yellowTextButton,redTextButton, brownTextButton, voiletTextButton, grayTextButton, cyanTextButton]
        buttonArray.forEach{
            $0?.isSelected = false
        }
        sender.isSelected = true
        self.messageTextField.textColor  = getColor(index: sender.tag)
     }
    
    
    /// it will change the view background color
    ///
    /// - Parameter sender: tapped button
    @IBAction func changeTextViewBGColor(_ sender: UIButton) {
        let buttonArray = [blackBGButton,whiteBGButton,blueBGButton,greenBGButton,yellowBGColor,redBGButton, brownBGButton, voiletBGButton, grayBGButton, cyanBGButton]
        buttonArray.forEach{
            $0?.isSelected = false
        }
        sender.isSelected = true
        self.view.backgroundColor  = getColor(index: sender.tag)
    }

    
}


//
//
//
//
//

// show Attachment View

extension TextEditorVC {
    
    /// show make a notes screen
    func showNotesAttachment() {
        
        self.view.addSubview(notesAttachmentView)
        notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1) {
            self.notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }
        
        notesAttachmentView.isHidden = false
        
    }
    
    
    func dismissNotesAttachments()  {
        
        notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        
        //notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1, animations: {
            self.notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }) { (_) in
            self.notesAttachmentView.isHidden = false
            self.notesAttachmentView.removeFromSuperview()
        }
        
        
    }
    
}


//extension TextEditorVC {
//
//    func showAttachEditorView()  {
//
//        let attachView = UIView()
//        attachView.backgroundColor = .white
//        attachView.translatesAutoresizingMaskIntoConstraints = false
//
//
//        attachView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10).isActive = true
//        attachView.trailingAnchor.constraint(equalTo: self.view., constant: <#T##CGFloat#>)
//
//
//
//    }
//
//
//
//}
