//
//  DashboardModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

/// operation performed by user
///
/// - Get: get How many baords having a user
/// - Add: user add board
/// - Delete: user delete the board
enum BoardOperation :String {
    
    case Get
    case Add
    case Delete
}

/// Dashboard Model class
class DashboardModel {
    
    typealias userboardData = (Bool) -> Void
    lazy var alertMessage: String = ""
    lazy var totalBoard = 0
    lazy var boardsArray = [UserBoardData]()
    
    init() {
        
        // do nothing here...
    }
    
}

// MARK: - Get userboard Data
/// - Parameters:
///   - boardId:
///   - boardOperation: 1. Get userboard Data, 2. Add userboard, 3. Delete userboard
extension DashboardModel {
  
    
    func getRequestDataDictionary(_ boardId: Int, boardOperation: String, token: String, userID: String ) -> [String:Any]  {
        
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kToken] = token
        requestData["userid"] = userID
        
        if boardOperation == BoardOperation.Delete.rawValue {
            
            requestData["boardid"] = boardId
            
        }
        var userboardDataDict = [String: Any]()
        userboardDataDict["RequestData"] = requestData
      
        return userboardDataDict
        
    }
    
    
    
    func getUserboardData(_ boardId: Int, boardOperation: String,completionHandler: @escaping userboardData) {
        
        var getUserboardURL = ""
        
        guard let token = Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) else { return }
        guard let userID = Helper.getUserDefault(key: "userId") else { return }
        
        if boardOperation == BoardOperation.Get.rawValue {
            getUserboardURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.getUserboard
        }
        else if boardOperation == BoardOperation.Add.rawValue {
            getUserboardURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.addUserboard
        }
        else {
            getUserboardURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.deleteUserboard
        }
        
        let userboardDataDict = getRequestDataDictionary(boardId, boardOperation: boardOperation, token: token, userID: userID)

        APIManager.shared.postService(getUserboardURL, andParameter: userboardDataDict) { (data, error) in
            
            if error != nil  {
                self.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            } else {
                
                do {
                  let userboardModelData = try JSONDecoder().decode(UserboardModel.self, from: data!)
                  self.totalBoard = (userboardModelData.response?.totalBoard)!
                  self.boardsArray = (userboardModelData.response?.userboardData)!
                  completionHandler(true)
                    
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
        }
    }
}
    
// MARK: - update useboard Title
/// - Parameters:
///   - boardId: selected board Id
///   - boardName: Updated boardName
///   - completionHandler: success -> true, fail -> false
extension DashboardModel {
    
    func updateUseboardTitle(_ boardId: Int, boardName: String, completionHandler: @escaping userboardData) {
        
        guard let token = Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) else { return  }
        guard let userID = Helper.getUserDefault(key: "userId") else { return  }
        
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kToken] = token
        requestData["userid"] = userID
        requestData["boardid"] = boardId
        requestData["board_name"] = boardName
        
        var updateUserboardDataDict = [String: Any]()
        updateUserboardDataDict["RequestData"] = requestData
        
        
        let updateUserboardNameURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.updateUserboardName
        
        APIManager.shared.postService(updateUserboardNameURL, andParameter: updateUserboardDataDict) {[weak self] (data, error) in
            
            if error != nil  {
                self!.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            } else {
                
                do {
                    let userboardModelData = try JSONDecoder().decode(UpdateUserboardTitleModel.self, from: data!)
                    
                    print(userboardModelData)
                    completionHandler(true)
                    
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self?.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self?.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
        }
    }
}

