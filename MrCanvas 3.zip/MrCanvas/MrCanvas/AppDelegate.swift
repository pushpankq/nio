//
//  AppDelegate.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      
        
        IQKeyboardManager.sharedManager().enable = true
        self.storyBoardHandler()
        return false
    }
    
    func applicationWillResignActive(_ application: UIApplication) { }
    
    func applicationDidEnterBackground(_ application: UIApplication) { }
    
    func applicationWillEnterForeground(_ application: UIApplication) { }
    
    func applicationDidBecomeActive(_ application: UIApplication) { }
    
    func applicationWillTerminate(_ application: UIApplication) { }
    
    /// AutoLogin Functionality Handle
    /// First Time root VC will be Get started
    /// If app contains usertoken, root VC will be Dashboard
    /// If app will logout after the installation, root vc will be Sync Account
    /// Author:- Pushpank @date Apr 22, 2019
    func storyBoardHandler()  {
        
        if Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) != nil {
            
            let dashboard = UIStoryboard(name: Constants.Storyboard.main, bundle: nil).instantiateViewController(withIdentifier: Constants.Storyboard.StoryboardID.kAutoLoginNav)
            window?.rootViewController = dashboard
            
        } else if Helper.getUserDefault(key: "installed") != nil {
            
            let syncAccountVC = UIStoryboard(name: Constants.Storyboard.main, bundle: nil).instantiateViewController(withIdentifier: "SyncAccountVC")
            window?.rootViewController = syncAccountVC
            
        }
    }
    
}

