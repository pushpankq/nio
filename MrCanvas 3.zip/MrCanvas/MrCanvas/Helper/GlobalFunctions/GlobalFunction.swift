//
//  GlobalFunction.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import UIKit

/// Check email is valid or not
///
/// - Parameter emailString: user email
/// - Returns: if email is valid return true otherwise return false
func isValidEmail(emailString:String) -> Bool {
    
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailTest.evaluate(with: emailString)
    
}


/// Color Array
///
/// - Parameter index: button tag
/// - Returns: set color 
func getColor(index: Int) -> UIColor {
    
    let arrayIndex = index - 1
    let colorArray = [UIColor.black,
                      UIColor.white,
                      UIColor.blue,
                      UIColor.green,
                      UIColor.yellow,
                      UIColor.red,
                      UIColor.brown,
                      UIColor.init(red: 130/255, green: 0/255, blue: 139/255, alpha: 1),
                      UIColor.init(red: 105/255, green: 105/255, blue: 105/255, alpha: 1),
                      UIColor.init(red: 0/255, green: 139/255, blue: 139/255, alpha: 1)]
    return colorArray[arrayIndex]

}


/// Getting the font Size (Large, Medium, Small)
///
/// - Parameter index: seleted button tag
/// - Returns: set font size 
func getFontSize(index: Int) -> CGFloat {
    
    let arrayIndex = index - 1
    let fontSizeArray = [32,24,16]
    return CGFloat(fontSizeArray[arrayIndex])

}


func drawDottedLine(start p0: CGPoint, end p1: CGPoint, view: UIView) {
    let shapeLayer = CAShapeLayer()
    shapeLayer.strokeColor = UIColor.lightGray.cgColor
    shapeLayer.lineWidth = 1
    shapeLayer.lineDashPattern = [2, 2] // 7 is the length of dash, 3 is length of the gap.
    
    let path = CGMutablePath()
    path.addLines(between: [p0, p1])
    shapeLayer.path = path
    view.layer.addSublayer(shapeLayer)
}

func methodForPopViewController(viewController:AnyClass,navigation:UINavigationController){
    for controller in navigation.viewControllers as Array {
        if controller.isKind(of: viewController.self) {
            navigation.popToViewController(controller, animated: false)
            break
        }
    }
    
}
