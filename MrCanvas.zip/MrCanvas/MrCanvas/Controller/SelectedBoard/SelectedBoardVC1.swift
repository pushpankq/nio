//
//  SelectedBoardVC1.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import Filestack
import FilestackSDK

class SelectedBoardVC1: UIViewController {
    
    @IBOutlet var animatedView: UIView!
    @IBOutlet weak var textEditorImageView: UIImageView!
    @IBOutlet weak var searchImageView: UIImageView!
    @IBOutlet weak var photoPickerImageView: UIImageView!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    
    fileprivate var longPressGesture: UILongPressGestureRecognizer!

    
//    var effect: UIVisualEffect!
    
    @IBOutlet var notesAttachmentView: UIView!
    
    @IBOutlet weak var selectedCollectionView: UICollectionView! {
        didSet {
            
            selectedCollectionView.delegate = self
            selectedCollectionView.dataSource = self
            selectedCollectionView.isScrollEnabled = false
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
        selectedCollectionView.addGestureRecognizer(longPressGesture)


//        effect = visualEffectView.effect
//        visualEffectView.effect = nil
        
        animatedView.layer.cornerRadius = 5
        
        let viewWidth = UIScreen.main.bounds.width
        let viewHeight = UIScreen.main.bounds.height
        let layout = UICollectionViewFlowLayout()
        self.selectedCollectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: viewWidth/4 - 2, height: viewHeight/4 - 2)
        layout.minimumInteritemSpacing = 2
        layout.minimumLineSpacing = 2
        selectedCollectionView.collectionViewLayout = layout
        selectedCollectionView.reloadData()
        
        let openTextEditorTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openTextEditor(tapGestureRecognizer:)))
        textEditorImageView.isUserInteractionEnabled = true
        textEditorImageView.addGestureRecognizer(openTextEditorTapGestureRecognizer)
        
        let openSearchEngineTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openSearchEngine(tapGestureRecognizer:)))
        searchImageView.isUserInteractionEnabled = true
        searchImageView.addGestureRecognizer(openSearchEngineTapGestureRecognizer)
        
        let openFilePickerTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openFilePicker(tapGestureRecognizer:)))
        photoPickerImageView.isUserInteractionEnabled = true
        photoPickerImageView.addGestureRecognizer(openFilePickerTapGestureRecognizer)

    }
    
    @IBAction func makeANoteButtonPressed(_ sender: UIButton) {
        
        showNotesAttachment()
    }
    
    func addBlurEffect()
    {
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.alpha = 0.5
        blurEffectView.frame = self.view.bounds
        
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        self.selectedCollectionView.addSubview(blurEffectView)
    }
    

    @objc func handleLongGesture(gesture: UILongPressGestureRecognizer) {
        switch(gesture.state) {
            
        case .began:
            guard let selectedIndexPath = selectedCollectionView.indexPathForItem(at: gesture.location(in: selectedCollectionView)) else {
                break
            }
            selectedCollectionView.beginInteractiveMovementForItem(at: selectedIndexPath)
        case .changed:
            selectedCollectionView.updateInteractiveMovementTargetPosition(gesture.location(in: gesture.view!))
        case .ended:
            selectedCollectionView.endInteractiveMovement()
        default:
            selectedCollectionView.cancelInteractiveMovement()
        }
    }
    
    
    // add board gesture defination
    @objc func openTextEditor(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "ShowTextEditor", sender: self)
     
    }
    
    // add board gesture defination
    @objc func openSearchEngine(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "ShowSearchEngine", sender: self)
        
    }
    
    func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        
        return true
    }
    
    private func animateIn() {
        
        self.view.addSubview(animatedView)
        animatedView.center = self.selectedCollectionView.center
        animatedView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        animatedView.alpha = 0
        
        UIView.animate(withDuration: 0.4) {
//            self.visualEffectView.effect = self.effect
            self.animatedView.alpha = 1
            self.animatedView.transform = CGAffineTransform.identity
        }
        
    }


}


extension SelectedBoardVC1 : UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 16
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newCell", for: indexPath) as! SelectedBoardCollectionViewCell
        cell.backgroundColor = .red
        cell.layer.cornerRadius = 8
        return cell
    }
    
    
    
}


extension SelectedBoardVC1: UICollectionViewDelegate {
    
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            let cell = collectionView.cellForItem(at: indexPath) as! SelectedBoardCollectionViewCell
            for subview in cell .subviews
            {
                if let item = subview as? UIImageView
                {
                    print("imageview \(item)")
                }
                else if let item = subview as? UITextView {
                    print("UITextView \(item)")
                    
                } else {
                    
//                    addBlurEffect()
                    animateIn()
                }
            }
        }
    
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
                print("Starting Index: \(sourceIndexPath.item)")
            print("Ending Index: \(destinationIndexPath.item)")
        
    }
    
}
//
//
//
//
//

// show Attachment View

extension SelectedBoardVC1 {
    
    /// show make a notes screen
    func showNotesAttachment() {
        
        self.view.addSubview(notesAttachmentView)
        notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1) {
            self.notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }
        
        notesAttachmentView.isHidden = false
        
    }
    
    
    @IBAction func unwindToSelectedBoardVC(segue: UIStoryboardSegue) {
    }
    
    func dismissNotesAttachments()  {
        
        notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        
        //notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1, animations: {
            self.notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }) { (_) in
            self.notesAttachmentView.isHidden = false
            self.notesAttachmentView.removeFromSuperview()
        }
        
        
    }
    
}


//
//
//
//
//

// Access Filestack


extension SelectedBoardVC1 {
    
    // add board gesture defination
    @objc func openFilePicker(tapGestureRecognizer: UITapGestureRecognizer) {
        
        
        
        
        // Initialize a `Policy` with the expiry time and permissions you need.
        let oneDayInSeconds: TimeInterval = 60 * 60 * 24 // expires tomorrow
        let policy = Policy(// Set your expiry time (24 hours in our case)
            expiry: Date(timeIntervalSinceNow: oneDayInSeconds),
            // Set the permissions you want your policy to have
            call: [.pick, .read, .store])
        
        // Initialize a `Security` object by providing a `Policy` object and your app secret.
        // You can find and/or enable your app secret in the Developer Portal.
        guard let security = try? Security(policy: policy, appSecret: "2RNLTY2OEFAJRCMAZEPYYESR5I") else {
            return
        }
        let config = Filestack.Config()
        
        // Make sure to assign an app scheme URL that matches the one configured in your info.plist.
        config.appURLScheme = "filestackdemo"
        
        let client = Filestack.Client(apiKey: "Ap8CMkDyGQyi9pUHcpajiz", security: security, config: config)
        
        config.availableCloudSources = [.facebook, .instagram, .googleDrive, .dropbox, .box, .gitHub, .gmail, .googlePhotos, .oneDrive, .amazonDrive]
        let picker = client.picker()
        
        
        self.present(picker, animated: true)
        
    }
}
