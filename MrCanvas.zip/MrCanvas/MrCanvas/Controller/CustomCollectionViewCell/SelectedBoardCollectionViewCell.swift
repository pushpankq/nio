//
//  SelectedBoardCollectionViewCell.swift
//  MrCanvas
//
//  Created by Mayank Singh on 18/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class SelectedBoardCollectionViewCell: UICollectionViewCell {
    
//    @IBOutlet weak var cellLabel: UILabel!
//    @IBOutlet weak var cellView: UIView!
}
