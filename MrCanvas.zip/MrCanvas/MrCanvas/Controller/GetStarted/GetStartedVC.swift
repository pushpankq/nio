//
//  GetStartedVC1.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class GetStartedVC: UIPageViewController {
    
    var pageControl : UIPageControl = UIPageControl()
    var nextImageView = UIImageView()
    var index = 0
    lazy var viewControllerArray: [UIViewController] = {
        return [
            
            UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AppBasicVC") as! AppBasicVC,
            UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CollectionVC") as! CollectionVC,
            UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "OrganiseVC") as! OrganiseVC,
            UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PresentVC") as! PresentVC,
//            UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SyncAccountVC") as! SyncAccountVC,
            ]
    }()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.dataSource = self
        setViewControllers([viewControllerArray[0]], direction: .forward, animated: true, completion: nil)
        nextButtonSetUp()
        configurePageControl()

    }
    
    
    func nextButtonSetUp()  {
        
        self.view.addSubview(nextImageView)
        
        nextImageView.image = UIImage(named: "next")
        nextImageView.clipsToBounds = true
        nextImageView.contentMode = .scaleAspectFit
        
        // add board tap gesture
        let nextTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(goNext(tapGestureRecognizer:)))
        nextImageView.isUserInteractionEnabled = true
        nextImageView.addGestureRecognizer(nextTapGestureRecognizer)
        
        nextImageView.translatesAutoresizingMaskIntoConstraints = false
        
        nextImageView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 30).isActive = true
        nextImageView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        nextImageView.heightAnchor.constraint(equalToConstant: 30.0).isActive = true
        nextImageView.widthAnchor.constraint(equalToConstant: 30.0).isActive = true
        
        
    }
    
    // add board gesture defination
    @objc func goNext(tapGestureRecognizer: UITapGestureRecognizer) {
        
        slideToPage()
    }
    
    
    func configurePageControl() {
        
        self.pageControl.numberOfPages = viewControllerArray.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.red
        self.pageControl.pageIndicatorTintColor = .black
        self.pageControl.currentPageIndicatorTintColor = .green
        self.view.addSubview(pageControl)
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        pageControl.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -20).isActive = true
        pageControl.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10).isActive = true
        pageControl.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10).isActive = true
        pageControl.heightAnchor.constraint(equalToConstant: 50).isActive = true

    }
    
    func slideToPage()  {
        
        if index < viewControllerArray.count-1 {
            
            index = index + 1
            print("index is \(index)")

            let pageControlIndex = index
            pageControl.currentPage = pageControlIndex
            self.setViewControllers([viewControllerArray[pageControlIndex]], direction: .forward, animated: true, completion: nil)
            
            if index > 3 {
                
                pageControl.isHidden = true
                nextImageView.isHidden = true
            } else {
                
                pageControl.isHidden = false
                nextImageView.isHidden = false
            }
        }
    }
    
}

// UIPageViewControllerDataSource 
// MARK: - UIPageViewControllerDataSource
extension GetStartedVC: UIPageViewControllerDataSource {
    
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return viewControllerArray.count
    }
    
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        let currentIndex = viewControllerArray.index(of:viewController) ?? 0
        if currentIndex <= 0 {
            
            index = currentIndex
            pageControl.currentPage = index
            return nil
        }
        
        pageControl.isHidden = false
        index = currentIndex
        
        print("index page \(index)")
        pageControl.currentPage = index
        return viewControllerArray[currentIndex - 1]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        let currentIndex = viewControllerArray.index(of:viewController) ?? 0
        index = currentIndex
        pageControl.currentPage = index
        print("index page \(index)")
        
        if currentIndex >= viewControllerArray.count-1 {
            
            pageControl.isHidden = true
            nextImageView.isHidden = true
            return nil
        }
                
        return viewControllerArray[currentIndex + 1]
    }

}




