//
//  BasicShopVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 08/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class BasicShopVC: UIViewController {

    @IBOutlet weak var purchasedButtonOutlet: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        designSetup()
    }
    
    
    func designSetup()  {
        purchasedButtonOutlet.layer.cornerRadius = 8.0
        titleLabel.text = "Basic"
        subtitleLabel.text = "Collect and orgnise your visual notes in style. Save websites, images and text."
    }

}
