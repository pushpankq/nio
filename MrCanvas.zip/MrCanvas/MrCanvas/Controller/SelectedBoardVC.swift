//
//  SelectedBoardVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 15/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class SelectedBoardVC: UIViewController {
//    @IBOutlet weak var selctedCollectionView: UICollectionView!{
//
//        didSet {
//            selctedCollectionView.delegate = self
//            selctedCollectionView.dataSource = self
//            selctedCollectionView.isScrollEnabled = false
////            selctedCollectionView.allowsSelection = false
//
//
//        }
//    }
    
    let array = ["he", "hello"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
//
//        selctedCollectionView.dataSource = self
//        selctedCollectionView.delegate = self

//        
//        let viewWidth = UIScreen.main.bounds.width
//        let viewHeight = UIScreen.main.bounds.height
//
//        let layout = UICollectionViewFlowLayout()
//
//        self.selctedCollectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
//        layout.itemSize = CGSize(width: viewWidth/4 - 2, height: viewHeight/4 - 2)
//
//        layout.minimumInteritemSpacing = 2
//        layout.minimumLineSpacing = 2
//       selctedCollectionView.collectionViewLayout = layout
        
//        selctedCollectionView.reloadData()
        

    }
    
    
    func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        
        return true
    }



 
}





//extension SelectedBoardVC: UICollectionViewDataSource, UICollectionViewDelegate , UICollectionViewDelegateFlowLayout{
//
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 1
//    }
//
//
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//
//        print("itesm")
////        return array.count
//        return 16
//    }
//
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//
//
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newCell", for: indexPath) as! SelectedBoardCollectionViewCell
//
////        cell.isUserInteractionEnabled = false
//        cell.cellView.backgroundColor = .blue
//        cell.cellLabel.text = "hi"
//
////
////        // delete board tap gesture
////        let showSelectedBoardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(showSelectedBoard(tapGestureRecognizer:)))
////        cell.isUserInteractionEnabled = true
////        cell.addGestureRecognizer(showSelectedBoardTapGestureRecognizer)
//
//
//        return cell
//    }
//
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//
//        let cell = collectionView.cellForItem(at: indexPath) as! SelectedBoardCollectionViewCell
//
//
//        for subview in cell .subviews
//        {
//            if let item = subview as? UIImageView
//            {
//
//                print("imageview")
//            }
//            else if let item = subview as? UITextView {
//
//                print("UITextView")
//
//
//
//            } else if let item = subview as? UIView {
//
//                print("UIView")
//
//
//
//            }
//        }
//    }
//
//
//}



//class FlowLayout: UICollectionViewFlowLayout {
//
//
//
//
//}
