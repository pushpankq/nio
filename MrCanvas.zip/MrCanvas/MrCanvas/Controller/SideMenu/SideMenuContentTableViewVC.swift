//
//  SideMenuContentTableViewVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import SideMenu

class SideMenuContentTableViewVC: UIViewController {
    
    
    let headerArray  = ["Sync Account", "Help", "Shop" , "Contact"]
    let cellArray  = [["Sign up for free or login"], ["Welcome Guide",
                                                      "Getting Started",
                                                      "Support"], ["Basic",
                                                                   "Premium"],["Rate MrCanvas",
                                                                               "Follow on Twitter",
                                                                               "Send us Feedback",
                                                                               "Read our Blog"]]
    let headerImageArray = [#imageLiteral(resourceName: "account"), #imageLiteral(resourceName: "help"), #imageLiteral(resourceName: "shop"), #imageLiteral(resourceName: "contact")]

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        self.tableView.separatorStyle = .none
        self.tableView.showsHorizontalScrollIndicator = false
        self.tableView.showsVerticalScrollIndicator = false

    }
}

extension SideMenuContentTableViewVC: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return headerArray.count
    }
    

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headerArray[section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellArray[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = cellArray[indexPath.section][indexPath.row]
        cell?.textLabel?.textColor = UIColor.init(red: 252/255, green: 111/255, blue: 10/255, alpha: 1)
        return cell!
    }
    
}

extension SideMenuContentTableViewVC : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: tableView.bounds.origin.y, width: tableView.frame.width, height: 50))
        headerView.backgroundColor = .white

        let headerTitle = UILabel()
        headerTitle.frame = CGRect.init(x: 55, y: 2, width: headerView.frame.width-10, height: 40)
        headerView.addSubview(headerTitle)
        headerTitle.text = self.headerArray[section]
        headerTitle.textColor = .black
        let headerIcon = UIImageView()
        headerIcon.frame = CGRect.init(x: 5, y: 5, width: 30, height:30)
        headerView.addSubview(headerIcon)
        headerIcon.clipsToBounds = true
        headerIcon.contentMode = .scaleAspectFit
        headerIcon.image = headerImageArray[section]
        return headerView
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.dismiss(animated: true, completion: nil)
        methodForPopViewController(viewController: DashboardVC.self, navigation: self.navigationController!)

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if cellArray[indexPath.section][indexPath.row] == "Welcome Guide" {
            let getStartedVC = storyboard.instantiateViewController(withIdentifier: "GetStartedVC")
            self.navigationController?.pushViewController(getStartedVC, animated: true)
        }

        else if cellArray[indexPath.section][indexPath.row] == "Read our Blog" {
            self.performSegue(withIdentifier: "SHowIt", sender: self)
        }
        else if cellArray[indexPath.section][indexPath.row] == "Basic" {
            self.performSegue(withIdentifier: "shopBasicID", sender: self)
        }
            
        else if cellArray[indexPath.section][indexPath.row] == "Premium" {
            self.performSegue(withIdentifier: "shopPremiumID", sender: self)
        }
        
        
        else {
            
//            let url = NSURL(string: "https://google.com")!
//            UIApplication.shared.openURL(url as URL)
        }
    }
 
}
