//
//  WebBrowserVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 04/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import WebKit

class WebBrowserVC: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var searchBar: UISearchBar!
    var myActivityIndicator = UIActivityIndicatorView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Create Custom ActivityIndicator
        myActivityIndicator.center = self.view.center
        myActivityIndicator.style = .gray
        view.addSubview(myActivityIndicator)
        
        //Adding observer for show loading indicator
        self.webView.addObserver(self, forKeyPath:#keyPath(WKWebView.isLoading), options: .new, context: nil)
        searchBar.delegate = self
        self.searchBar.delegate = self
        
        self.searchBar.becomeFirstResponder()
        
        
//        if let searchTextField:UITextField = searchBar.subviews[0].subviews[2] as? UITextField {
//            searchTextField.enablesReturnKeyAutomatically = false
//        }
//        
//        searchBar.enablesReturnKeyAutomatically = false
//
//        if (searchBar.text?.isEmpty)! {
//
//            for view1 in searchBar.subviews {
//                for view2 in view1.subviews {
//                    if let searchBarTextField = view2 as? UITextField {
//                        searchBarTextField.enablesReturnKeyAutomatically = true
//                        break
//                    }
//                }
//            }
//
//        }
    }
    
    
    //MARK: - ActivityIndicator StartAnimate And StopAnimate
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "loading"{
            if webView.isLoading{
                myActivityIndicator.startAnimating()
                myActivityIndicator.isHidden = false
            }else{
                myActivityIndicator.stopAnimating()
            }
        }
    }

}

//MARK: - Load Url In Webview
extension WKWebView {
    func loadUrl(string: String) {
        if let url = URL(string: string) {
            load(URLRequest(url: url))
        }
    }
}

//
//
//
//
//

// Search Bar Delegates 

extension WebBrowserVC: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
        
        func searchTextOnGoogle(text: String){
            let textComponent = text.components(separatedBy: " ")
            let searchString = textComponent.joined(separator: "+")
            let url = URL(string: "https://www.google.com/search?q=" + searchString)
            let urlRequest = URLRequest(url: url!)
            webView.load(urlRequest)
        }
        if let urlString = searchBar.text{
            if urlString.starts(with: "http://") || urlString.starts(with: "https://"){
                webView.loadUrl(string: urlString)
            }else if urlString.contains("www"){
                webView.loadUrl(string: "http://\(urlString)")
            }else{
                searchTextOnGoogle(text: urlString)
            }
        }
    }
    
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        
//        UITextField *searchBarTextField = nil;
//        for (UIView *subview in self.searchBar.subviews)
//        {
//            if ([subview isKindOfClass:[UITextField class]])
//            {
//                searchBarTextField = (UITextField *)subview;
//                break;
//            }
//        }
//        searchBarTextField.enablesReturnKeyAutomatically = NO;
        
        
        for view1 in searchBar.subviews {
            for view2 in view1.subviews {
                if let searchBarTextField = view2 as? UITextField {
                    searchBarTextField.enablesReturnKeyAutomatically = false
                    break
                }
            }
        }
        
        
    }

}
