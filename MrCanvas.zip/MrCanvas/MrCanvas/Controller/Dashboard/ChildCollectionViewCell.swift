//
//  ChildCollectionViewCell.swift
//  MrCanvas
//
//  Created by Mayank Singh on 18/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class ChildCollectionViewCell: UICollectionViewCell {
    
    let childView: UIView = {
        
        let view = UIView()
        view.backgroundColor = .red
        view.layer.cornerRadius = 6
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func addViews(){
        
        addSubview(childView)
        childView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        childView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        childView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.25, constant: -20).isActive = true
        childView.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.25, constant: -4).isActive = true
        
    }
    

    
}
