//
//  ChildCollectionViewCell.swift
//  MrCanvas
//
//  Created by Mayank Singh on 18/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class ChildCollectionViewCell: UICollectionViewCell {
    
}
