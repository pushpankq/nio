//
//  LoginModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

enum OperationType :String{
    case SignUp
    case Login
}

class SyncAccountModel {
    
    // Completion Handler
    typealias loginData = (Bool) -> Void
    typealias userProfileData = (Bool) -> Void

    
    lazy var alertMessage: String = ""
    lazy var email: String = ""
    lazy var password: String = ""
    lazy var successBool = false
    lazy var requestData = [String:Any]()
    
    
    init(email: String, password: String) {
        
        self.email = email
        self.password = password
        self.alertMessage = ""
    }
    
    /// Login form Validation
    ///
    /// - Returns: form is valid or not
    func loginFormValidate() -> Bool {
        
        if email.isEmpty || password.isEmpty ||  !isValidEmail( emailString: email) {
            
            alertMessage = Constants.Validation.emailOrPasswordErrorMessage
            return false
        }
        return true
    }
    

    /// Accessing data from Login web api
    ///
    /// - Parameter completionHandler: using callback to send data in controller
    func userLogin(_ operationType: String, completionHandler: @escaping loginData)  {
        
        var loginOrSignUpURL = ""
        
        if operationType == OperationType.Login.rawValue {
            loginOrSignUpURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.loginUser
        }
        else if operationType == OperationType.SignUp.rawValue {
            loginOrSignUpURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.createUser
        }

        let dataDictionary = createRequestData(operationType)
        
        APIManager.shared.postService(loginOrSignUpURL, andParameter: dataDictionary) { [weak self] (data, error) in
            
            if error != nil  {
                self!.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            }  else {
                    do {
                    let loginData = try JSONDecoder().decode(LoginModel.self, from: data!)
                        let isSuccess = loginData.successBool
                        if isSuccess! {
                            
                            let userId = (loginData.response?.user_id)!
                            
                            print("login data ", loginData)
                            
                            Helper.saveUserDefault(key: "userToken", value: (loginData.response?.userToken)!)
                            Helper.saveUserDefault(key: "userId", value: String(userId))
                            Helper.saveUserDefault(key: "emailId", value: (loginData.response?.email)!)
                            
                            self?.getProfile(userID: userId, completionHandler: { (isSuccess) in
                                
                                if isSuccess {
                                completionHandler(true)
                                } else {
                                    completionHandler(false)
                                }
                            })
                        }
                        
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self?.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self?.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
        }
    }

    /// Accessing data from User SignUp web api
    ///
    /// - Parameter completionHandler: using callback to send data in controller
    func getProfile(userID: Int , completionHandler: @escaping userProfileData) {
        
        let getProfileURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.getProfle
        var requestData = [String:Any]()
        
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kDeviceType] = Constants.ApiKeysValues.iOS
        requestData["userid"] = userID
        
        var registerDataDict = [String: Any]()
        registerDataDict["RequestData"] = requestData
        
        APIManager.shared.postService(getProfileURL, andParameter: registerDataDict) {[weak self] (data, error) in
            
            if error != nil  {
                self!.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            } else {
                
                do {
                    let profileData = try JSONDecoder().decode(ProfileModel.self, from: data!)
                    print("profileData", profileData)
                    completionHandler(true)
                    
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self?.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self?.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
            
        }
        
    }

    
    /// Creating request body for accessing the web api
    ///
    /// - Parameter isLogin: if isLogin is true, we are using the request body for user login api otherwise for user SignUp api
    /// - Returns: Request body
    func createRequestData(_ operationType: String) -> [String:Any] {
        
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kDeviceType] = Constants.ApiKeysValues.iOS
        requestData[Constants.ApiKeys.kDeviceID] = "fdgf"
        requestData[Constants.ApiKeys.kDeviceToken] = "fdgf"
        requestData[Constants.ApiKeys.kEmail] = email
        requestData[Constants.ApiKeys.kPassword] = password
        
        if operationType == OperationType.SignUp.rawValue {
            requestData[Constants.ApiKeys.kUsername] = email
        }
        
        var dataDictionary = [String: Any]()
        dataDictionary["RequestData"] = requestData
        return dataDictionary
    }
   
}
