//
//  LoginModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

class SyncAccountModel {
    
    var alertMessage: String
    var email: String
    var password: String
    
    init(email: String, password: String) {
        
        
        self.email = email
        self.password = password
        self.alertMessage = ""
    }
    
    func loginFormValidate() -> Bool {
        
        if email.isEmpty || password.isEmpty ||  !isValidEmail( emailString: email) {
            
            alertMessage = Contants.Validation.emailOrPasswordErrorMessage
            return false
        }
        
        return true
        
    }
    
    
}
