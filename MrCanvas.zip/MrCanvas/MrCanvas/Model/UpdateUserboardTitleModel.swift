//
//  UpdateUserboardNameModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 12/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

struct UpdateUserboardTitleModel : Codable {
    let successBool : Bool?
    let responseType : String?
    let successCode : String?
    let response : UpdateUserboardTitleResponse?
    let errorObj : ErrorObj?
    
    enum CodingKeys: String, CodingKey {
        
        case successBool = "successBool"
        case responseType = "responseType"
        case successCode = "successCode"
        case response = "response"
        case errorObj = "ErrorObj"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        successBool = try values.decodeIfPresent(Bool.self, forKey: .successBool)
        responseType = try values.decodeIfPresent(String.self, forKey: .responseType)
        successCode = try values.decodeIfPresent(String.self, forKey: .successCode)
        response = try values.decodeIfPresent(UpdateUserboardTitleResponse.self, forKey: .response)
        errorObj = try values.decodeIfPresent(ErrorObj.self, forKey: .errorObj)
    }
    
}

struct UpdateUserboardTitleResponse : Codable {
    let message : String?
    let board_name : String?
    
    enum CodingKeys: String, CodingKey {
        
        case message = "message"
        case board_name = "board_name"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        board_name = try values.decodeIfPresent(String.self, forKey: .board_name)
    }
    
}

