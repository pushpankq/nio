//
//  UserboardModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 10/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

struct UserboardModel : Codable {
    
    let successBool : Bool?
    let responseType : String?
    let successCode : String?
    let response : UserboardResponse?
    let errorObj : ErrorObj?
    
    enum CodingKeys: String, CodingKey {
        
        case successBool = "successBool"
        case responseType = "responseType"
        case successCode = "successCode"
        case response = "response"
        case errorObj = "ErrorObj"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        successBool = try values.decodeIfPresent(Bool.self, forKey: .successBool)
        responseType = try values.decodeIfPresent(String.self, forKey: .responseType)
        successCode = try values.decodeIfPresent(String.self, forKey: .successCode)
        response = try values.decodeIfPresent(UserboardResponse.self, forKey: .response)
        errorObj = try values.decodeIfPresent(ErrorObj.self, forKey: .errorObj)
    }
    
}

struct UserboardResponse : Codable {
    let message : String?
    let userboardData : [UserBoardData]?
    let totalBoard : Int?
    
    enum CodingKeys: String, CodingKey {
        
        case message = "message"
        case userboardData = "data"
        case totalBoard = "totalBoard"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        userboardData = try values.decodeIfPresent([UserBoardData].self, forKey: .userboardData)
        totalBoard = try values.decodeIfPresent(Int.self, forKey: .totalBoard)
    }
    
}

struct UserBoardData : Codable {
    let board_id : Int?
    var board_name : String?
    let box_data : Box_data?
    
    enum CodingKeys: String, CodingKey {
        
        case board_id = "board_id"
        case board_name = "board_name"
        case box_data = "box_data"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        board_id = try values.decodeIfPresent(Int.self, forKey: .board_id)
        board_name = try values.decodeIfPresent(String.self, forKey: .board_name)
        box_data = try values.decodeIfPresent(Box_data.self, forKey: .box_data)
    }
    
}

struct Box_data : Codable {
    let board_data : [Board_data]?
    
    enum CodingKeys: String, CodingKey {
        
        case board_data = "board_data"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        board_data = try values.decodeIfPresent([Board_data].self, forKey: .board_data)
    }
    
}

struct Board_data : Codable {
    let id : Int?
    let position : Int?
    let data_type : String?
    let data : String?
    
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case position = "position"
        case data_type = "data_type"
        case data = "data"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        position = try values.decodeIfPresent(Int.self, forKey: .position)
        data_type = try values.decodeIfPresent(String.self, forKey: .data_type)
        data = try values.decodeIfPresent(String.self, forKey: .data)
    }
    
}

