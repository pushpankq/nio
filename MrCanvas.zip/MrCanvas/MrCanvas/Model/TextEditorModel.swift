//
//  TextEditorModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/05/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

class TextEditorModel {
  
  lazy var alertMessage: String = ""

  
  init() {
    
    // Do nothing here...
  }
  
  
  func addTextEditorData(userId: String, textAlignment: String, textFontSize: String, bgColor: String, textColor: String, textViewText: String)  {
    
    guard let token = Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) else { return  }
    guard let userID = Helper.getUserDefault(key: "userId") else { return  }
    
    
    var requestData = [String:Any]()
    requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
    requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
    requestData[Constants.ApiKeys.kToken] = token
    requestData["userid"] = userID
    requestData["board_id"] = "500"
    requestData["card_id"] = "9"
    requestData["txt_alignment"] = "text-center"
    requestData["txt_font_size"] = "12px"
    requestData["txt_bg_color"] = "#ccc"
    requestData["txt_comment"] = "Hi Mohit this testing for Mohit..."
    
    
    var updateUserboardDataDict = [String: Any]()
    updateUserboardDataDict["RequestData"] = requestData
    
    let addTextURL = "http://160.153.247.88:3000/add_text"
    
    APIManager.shared.postService(addTextURL, andParameter: updateUserboardDataDict) {[weak self] (data, error) in
      
      print(error?.localizedDescription)
      
      if error != nil  {
        
        print("error message \(error?.localizedDescription)")
//        self!.alertMessage = (error?.localizedDescription)!
       // completionHandler(false)
      } else {
        
        do {
          let userboardModelData = try JSONDecoder().decode(UpdateUserboardTitleModel.self, from: data!)
          
          print(userboardModelData)
         // completionHandler(true)
          
        } catch  _ {
          do {
            let loginError = try JSONDecoder().decode(NewErrorModel.self, from: data!)
            self?.alertMessage = (loginError.errorObj?.errorMsg)!
            
            print(self?.alertMessage)
           // completionHandler(false)
            
          } catch let jsonFormatError {
            
            self?.alertMessage = jsonFormatError.localizedDescription
           // completionHandler(false)
          }
        }
      }
    }


    
  }

}
