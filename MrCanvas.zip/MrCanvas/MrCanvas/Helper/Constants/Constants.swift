//
//  Constants.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

enum Contants {
    
    enum Validation {
        
        static let emailOrPasswordErrorMessage = "This does not seem to be a valid email. \nPlease double check and try again."
    }
    
}
