//
//  Constants.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import UIKit

enum Constants {
    
    static let screenHeight = UIScreen.main.bounds.size.height
    static let screenWidth = UIScreen.main.bounds.size.width

    
    enum Validation {
        
        static let emailOrPasswordErrorMessage = "This does not seem to be a valid email. \nPlease double check and try again."
    }
    
    enum Alignment {
        
        static let top = "top"
        static let center = "center"
        static let bottom = "bottom"
        static let left = "left"
        static let right = "right"
    }
    
    enum ApiEndPoint {
        
        static let baseURL = "https://mrcanvas.com/api"
        static let createUser = "/user/create"
        static let loginUser = "/user/login"
        static let getProfle = "/user/profile"
        static let getUserboard = "/user/userboard"
        static let addUserboard = "/user/insertuserboard"
        static let deleteUserboard = "/user/deleteuserboard"
        static let updateUserboardName = "/user/updateboardname"


    }
    
    enum ApiKeysValues {
        
        static let apiKey = "41bbf547d64c309749b613f16323b762"
        static let iOS = "iOS"
        static let vCode = "1.0"
    }
    
    enum ApiKeys {
        
        static let kUsername = "username"
        static let kVCode = "v_code"
        static let kApiKey = "apikey"
        static let kDeviceType = "deviceType"
        static let kDeviceID = "deviceID"
        static let kDeviceToken = "device_token"
        static let kEmail = "email"
        static let kPassword = "password"
        static let kUserToken = "userToken"
        static let kToken = "token"

    }
    
    enum Storyboard {
        
        static let main = "Main"
        
        enum StoryboardID {
            static let kAutoLoginNav = "AutoLoginNav"
        }
        
        enum Identifier {
        }
    }
    
}




