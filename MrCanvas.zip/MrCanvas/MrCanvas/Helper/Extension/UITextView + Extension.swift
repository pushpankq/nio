//
//  UITextView + Extension.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import UIKit

extension UITextView {
    
    // left -- top align
    func topLeftAlignment() {

        let positiveTopOffset = max(1, 5)
        contentOffset.y = CGFloat(-positiveTopOffset)
        let topOffsetX = (0.0)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = CGFloat(-positiveTopOffsetX)
    }
    
    
    // left -- center align
    func centerLeftAlignment() {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let positiveTopOffsetX = max(1, 0)
        contentOffset.x = CGFloat(-positiveTopOffsetX)
    }
    
    // left -- bottom align
    func bottomLeftAlighment () {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale)
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let topOffsetX = (0.0)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = CGFloat(-positiveTopOffsetX)
        
        
        
    }

    
    // center -- top align
    func centerTopAlign() {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, 5)
        contentOffset.y = CGFloat(-positiveTopOffset)
        let topOffsetX = (bounds.size.width/2 - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX
    }
    
    // center -- center align
    func centerVertically() {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let topOffsetX = (bounds.size.width/2 - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX
    }
    
    // center -- bottom align
    func bottomCenterAlighment () {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale)
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let topOffsetX = (bounds.size.width/2 - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX
    }
    
    
    // right -- center align
    func topRightAlignment() {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let positiveTopOffset = max(1, 5)
        contentOffset.y = CGFloat(-positiveTopOffset)
        let topOffsetX = (bounds.size.width - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX
    }
    
    
    // right -- center align
    func centerRightAlignment() {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let topOffsetX = (bounds.size.width - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX
    }
    

    
    // right -- bottom align
    func bottomRightAlighment () {
        
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale)
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
        let topOffsetX = (bounds.size.width - size.width * zoomScale)
        let positiveTopOffsetX = max(1, topOffsetX)
        contentOffset.x = -positiveTopOffsetX

    }
    
    
    
  
}
