//
//  GlobalFunction.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

/// Check email is valid or not
///
/// - Parameter emailString: user email
/// - Returns: if email is valid return true otherwise return false
func isValidEmail(emailString:String) -> Bool {
    
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailTest.evaluate(with: emailString)
    
}

