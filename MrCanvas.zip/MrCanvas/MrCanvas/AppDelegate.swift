//
//  AppDelegate.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        
        print("didFinishLaunchingWithOptions")
        
        // Add AutoLogin Functionality
        if Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) != nil {
            let dashboard = UIStoryboard(name: Constants.Storyboard.main, bundle: nil).instantiateViewController(withIdentifier: Constants.Storyboard.StoryboardID.kAutoLoginNav)
            window?.rootViewController = dashboard
        }
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        
        print("applicationWillResignActive")

    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        
        print("applicationDidEnterBackground")

    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        
        print("applicationWillEnterForeground")

    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        
        print("applicationDidBecomeActive")
 
    }

    func applicationWillTerminate(_ application: UIApplication) {
        
        print("applicationWillTerminate")

    }

}

